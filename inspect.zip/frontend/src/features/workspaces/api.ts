import { api, getAccessToken } from '@/lib/api';

export interface UserBankMembership {
  id: string;
  name: string;
  code: string;
  isPrimary?: boolean;
  status?: string;
}

export interface UserProfile {
  id?: string;
  email: string;
  firstName: string;
  lastName: string;
  phone?: string;
  role: string;
  status?: string;
  isActive?: boolean;
  isEmailVerified?: boolean;
  emailVerifiedAt?: string | null;
  lastLoginAt?: string | null;
  createdAt: string;
  updatedAt?: string;
  banks?: UserBankMembership[];
}

export function parseJwt(token: string) {
  try {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    return JSON.parse(window.atob(base64));
  } catch {
    return null;
  }
}

export async function fetchCurrentWorkspaceUser(): Promise<UserProfile> {
  const token = getAccessToken();
  if (!token) throw new Error('No token');

  const res = await api.get<{ status: string; data: UserProfile }>('/users/me');
  return (res.data as any).data || res.data;
}

export interface WorkspaceBank {
  id: string;
  name: string;
  code: string;
}

export async function fetchMyBanks(): Promise<WorkspaceBank[]> {
  const res = await api.get<{ status: string; data: unknown[] }>(
    '/banks/my-banks',
  );
  const raw: unknown[] = (res.data as any).data ?? res.data ?? [];
  // Backend domain entities are serialized as { props: { id, name, code, ... } }.
  // Direct Prisma results (from membership join) come back flat.
  return raw.map((item: any) => {
    const b = item?.props ?? item;
    return { id: b.id, name: b.name, code: b.code } as WorkspaceBank;
  });
}
