import { Navigate, Route, Routes } from 'react-router-dom'
import { AdminLayout } from './components/layout/AdminLayout'
import { useAuth } from './features/auth/auth-context'
import { WorkspaceProvider } from './features/workspaces/workspace-context'
import { BanksPage } from './routes/BanksPage'
import { ChecklistsPage } from './routes/ChecklistsPage'
import { DashboardPage } from './routes/DashboardPage'
import { LoginPage } from './routes/LoginPage'
import { ProtectedRoute } from './routes/ProtectedRoute'
import { RequestsPage } from './routes/RequestsPage'
import { CreateRequestPage } from './routes/CreateRequestPage'
import { RequestDetailPage } from './routes/RequestDetailPage'
import { RepresentativesPage } from './routes/RepresentativesPage'
import { UsersPage } from './routes/UsersPage'
import { VehicleSettingsPage } from './routes/VehicleSettingsPage'
import { ProfilePage } from './routes/ProfilePage'

function LoginRoute() {
  const { status } = useAuth()
  if (status === 'authenticated') return <Navigate to="/" replace />
  return <LoginPage />
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginRoute />} />
      <Route
        element={
          <ProtectedRoute>
            <WorkspaceProvider>
              <AdminLayout />
            </WorkspaceProvider>
          </ProtectedRoute>
        }
      >
        <Route index element={<DashboardPage />} />
        <Route path="requests" element={<RequestsPage />} />
        <Route path="requests/new" element={<CreateRequestPage />} />
        <Route path="requests/:id" element={<RequestDetailPage />} />
        <Route path="representatives" element={<RepresentativesPage />} />
        <Route path="checklists" element={<ChecklistsPage />} />
        <Route path="banks" element={<BanksPage />} />
        <Route path="vehicle-settings" element={<VehicleSettingsPage />} />
        <Route path="users" element={<UsersPage />} />
        <Route path="profile" element={<ProfilePage />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
